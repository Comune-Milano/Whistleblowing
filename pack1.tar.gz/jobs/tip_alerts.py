# -*- coding: utf-8
# Implementation of the daily operations.
import fnmatch
import os
from datetime import datetime, timedelta

from sqlalchemy import not_
from sqlalchemy.sql.expression import func

from twisted.internet.defer import inlineCallbacks

from globaleaks import models
from globaleaks.handlers.admin.node import db_admin_serialize_node
from globaleaks.handlers.admin.notification import db_get_notification
from globaleaks.handlers.user import user_serialize_user
from globaleaks.jobs.job import LoopingJob
from globaleaks.models.config import ConfigFactory
from globaleaks.orm import transact
from globaleaks.utils.log import log
from globaleaks.utils.templating import Templating
from globaleaks.utils.utility import diff_in_days


__all__ = ['TipAlerts']


class TipAlerts(LoopingJob):
    interval = 86400
    monitor_interval = 43200

    @transact
    def find_itips_for_alerts(self, session, tid):
        """
        This function, checks all the InternalTips.
        (if InternalTip.state='new' and InternalTip.creation_date+15gg > current_time
            OR
        if InternalTip.state!='closed' and InternalTip.creation_date+60gg > current_time)
            SEND_MAIL_ALERT
        """

        config = ConfigFactory(session, 1)
        days_new = config.get_val('alert_15gg_new_tip')
        days_not_closed = config.get_val('alert_60gg_notclosed_tip')

        itips_new = session.query(models.User, models.InternalTip.progressive, models.ReceiverTip.id, models.InternalTip.creation_date) \
                        .filter(models.InternalTip.tid == tid,
                                models.ReceiverTip.internaltip_id == models.InternalTip.id,
                                models.InternalTip.status == 'new',
                                models.User.id == models.ReceiverTip.receiver_id) \
                        .all()

        log.info("NEW TIPS: " + str(len(itips_new)))

        if itips_new:
            self.send_alerts(session, tid, itips_new, 'new_tip_alert', days_new)

        itips_not_closed = session.query(models.User, models.InternalTip.progressive, models.ReceiverTip.id, models.InternalTip.creation_date) \
                        .filter(models.InternalTip.tid == tid,
                                models.ReceiverTip.internaltip_id == models.InternalTip.id,
                                models.InternalTip.status != 'closed',
                                models.User.id == models.ReceiverTip.receiver_id) \
                        .all()

        log.info("NOT_CLOSED TIPS: " + str(len(itips_not_closed)))

        if itips_not_closed:
            self.send_alerts(session, tid, itips_not_closed, 'notclosed_tip_alert', days_not_closed)


    def send_alerts(self, session, tid, itips_ids, tip_type, num_days):
        for x in itips_ids:
            user = x[0]
            prg = x[1]
            rtip_id = x[2]
            creation_date = x[3]

            send_mail = False
            if tip_type=='new_tip_alert' and diff_in_days(datetime.now(), creation_date)==num_days:
                send_mail = True

            if tip_type=='notclosed_tip_alert' and diff_in_days(datetime.now(), creation_date)==num_days:
                send_mail = True

            if send_mail:
                user_desc = user_serialize_user(session, user, user.language)

                data = {
                    'type': tip_type,
                    'node': db_admin_serialize_node(session, tid, user.language),
                    'notification': db_get_notification(session, tid, user.language),
                    'user': user_desc,
                    'tip_prg': prg,
                    'days': num_days,
                    'rtip_id': rtip_id
                }

                subject, body = Templating().get_mail_subject_and_body(data)

                session.add(models.Mail({
                    'tid': 1,
                    'address': user_desc['mail_address'],
                    'subject': subject,
                    'body': body
                }))


    @inlineCallbacks
    def operation(self):
        log.info(" --------------> tip_alerts.operation")
        for tid in self.state.tenants:
            yield self.find_itips_for_alerts(tid)