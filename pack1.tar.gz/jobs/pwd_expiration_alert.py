# -*- coding: utf-8
# Implementation of the daily operations.
import fnmatch
import os
from datetime import datetime, timedelta

from sqlalchemy import not_
from sqlalchemy.sql.expression import func

from twisted.internet.defer import inlineCallbacks

from globaleaks import models
from globaleaks.handlers.admin.node import db_admin_serialize_node
from globaleaks.handlers.admin.notification import db_get_notification
from globaleaks.handlers.user import user_serialize_user
from globaleaks.jobs.job import LoopingJob
from globaleaks.models.config import ConfigFactory
from globaleaks.models.enums import EnumUserRole
from globaleaks.orm import transact
from globaleaks.utils.log import log
from globaleaks.utils.templating import Templating
from globaleaks.utils.utility import diff_in_days


__all__ = ['PwdExpirationAlert']


class PwdExpirationAlert(LoopingJob):
    interval = 86400
    monitor_interval = 43200

    @transact
    def find_receiver_with_expiring_pwd(self, session, tid):
        """
        This function, checks receivers with expiring password.
        """

        #devo cercare tutti gli utenti per i quali:
        #data di cambio password + password_change_period - pwd_expiring_warning < now
        users = session.query(models.User) \
                        .filter(models.User.tid == tid,
                                models.User.role == 1) \
                        .all()

        log.info("USERS: " + str(len(users)))

        if users:
            self.send_alerts(session, tid, users)


    def send_alerts(self, session, tid, users):
        config = ConfigFactory(session, 1)
        password_change_period = config.get_val('password_change_period')
        pwd_expiring_warning = config.get_val('pwd_expiring_warning_days')

        for u in users:
            pwd_change_time = u.password_change_date
            delta = timedelta(days=password_change_period)
            pwd_next_change_time = pwd_change_time + delta

            diff_days = diff_in_days(pwd_next_change_time, datetime.now())

            if  diff_days > 0 and diff_days <= pwd_expiring_warning:
                user_desc = user_serialize_user(session, u, u.language)

                data = {
                    'type': 'pwd_expiring_alert',
                    'node': db_admin_serialize_node(session, tid, u.language),
                    'notification': db_get_notification(session, tid, u.language),
                    'user': user_desc,
                    'days': diff_days
                }

                subject, body = Templating().get_mail_subject_and_body(data)

                mailing_list = config.get_val('pwd_expiring_mailing_list')
                ml_splitted = mailing_list.split(";", 1)

                for email in  ml_splitted:
                    session.add(models.Mail({
                        'tid': 1,
                        'address': email,
                        'subject': subject,
                        'body': body
                    }))


    @inlineCallbacks
    def operation(self):
        log.info(" --------------> pwd_expiration_alert.operation")
        for tid in self.state.tenants:
            yield self.find_receiver_with_expiring_pwd(tid)