# -*- coding: utf-8 -*-
#
# API handling export of submissions
import os
import csv
import base64

from io import BytesIO
from twisted.internet.defer import inlineCallbacks

from datetime import datetime

from globaleaks import models
from globaleaks.handlers.base import BaseHandler
from globaleaks.handlers.submission import decrypt_answers, extract_sensitive_answers, serialize_usertip
from globaleaks.orm import transact
from globaleaks.rest import errors
from globaleaks.utils.securetempfile import SecureTemporaryFile
from globaleaks.utils.zipstream import ZipStream
from globaleaks.utils.log import log


@transact
def prepare_all_tips_export(session, tid, receiver_id, start_date, end_date, lang, cc):
    """
    Transaction for performing operation on submissions (postpone/delete)

    :param session: An ORM session
    :param tid: A tenant ID
    :param receiver_id: A recipient ID
    :param operation: An operation command (export_all_tips)
    :param start_date: The start date for query
    :param end_date: The end date for query
    :param lang: The language
    :param cc: The cc
    """

    csv_info = "DATA INIZIO:;"+start_date+";;;\n"
    csv_info += "DATA FINE:;"+end_date+";;;\n\n"
    csv_info += "STATO SEGNALAZIONE;TIPOLOGIA SEGNALAZIONE;NUMERO;TEMPO MEDIO DI CHIUSURA (in giorni)\n"

    start_date_obj = datetime.strptime(start_date, '%d-%m-%Y')
    end_date_obj = datetime.strptime(end_date, '%d-%m-%Y')

    itips = session.query(models.InternalTip, models.ReceiverTip) \
                   .filter(models.ReceiverTip.receiver_id == receiver_id,
                           models.InternalTip.id == models.ReceiverTip.internaltip_id,
                           models.InternalTip.tid == tid,
                           models.InternalTip.creation_date >= start_date_obj,
                           models.InternalTip.creation_date <= end_date_obj)

    #tip[0] --> InternalTip
    #tip.id --> ReceiverTip.id

    #mostro se una segnalazione è confidenziale o anonima
    id_label_dict = {'43804667-19ee-4996-b562-80a58c0b9ffb':'Nome','9419b73b-c0e9-4509-b23b-d042762041f5':'Cognome'}
    new_anonymous = 0
    new_confidential = 0
    opened_anonymous = 0
    opened_confidential = 0
    closed_anonymous = 0
    closed_confidential = 0
    closed_anonymous_days = 0
    closed_confidential_days = 0

    for tip in itips:
        confidential = tip[0].is_confidential
        if confidential is None:
            tip_export = serialize_usertip(session, tip[1], tip[0], lang)
            ctpk = base64.b64decode(tip[1].crypto_tip_prv_key)
            if tip[1].crypto_tip_prv_key:
                tip_export["tip"] = decrypt_answers(cc, ctpk, tip_export)

            output_list = extract_sensitive_answers(tip_export["questionnaires"][0]["answers"], [], id_label_dict)
            if len(output_list) > 0:
                confidential = True
            else:
                confidential = False

            # inserisco una funzione in più, cioè la valorizzazione del campo is_confidential
            # in questo modo, negli export successivi non bisognerà più controllare se la
            # segnalazione è confidenziale.
            # update del campo is_confidential della segnalazione
            tip[0].is_confidential = confidential
            session.flush()

        if tip[0].status == 'new' and confidential:
            new_confidential += 1

        if tip[0].status == 'new' and not confidential:
            new_anonymous += 1

        if tip[0].status == 'opened' and confidential:
            opened_confidential += 1

        if tip[0].status == 'opened' and not confidential:
            opened_anonymous += 1

        #prendo la data di inserimento dello stato CHIUSA
        if tip[0].status == 'closed' and confidential:
            #recupero data di chiusura
            #la tabella submissionstatuschange non esiste piu'
            #prendo update_date da internaltip, nel momento in cui una segnalazione passa in stato 'closed'
            #update_date non cambia piu'
            #calcolo differenza in giorni con data di creazione
            delta = tip[0].update_date - tip[0].creation_date

            #fraz = round(delta.seconds / 86400, 2)
            #sommo i giorni ottenuti al contatore dei giorni
            closed_confidential_days += delta.days #+ fraz

            closed_confidential += 1

        if tip[0].status == 'closed' and not confidential:
            #recupero data di chiusura
            #la tabella submissionstatuschange non esiste piu'
            #prendo update_date da internaltip, nel momento in cui una segnalazione passa in stato 'closed'
            #update_date non cambia piu'
            #calcolo differenza in giorni con data di creazione
            delta = tip[1].last_access - tip[0].creation_date

            #fraz = round(delta.seconds / 86400, 2)
            #sommo i giorni ottenuti al contatore dei giorni
            closed_anonymous_days += delta.days #+ fraz
            closed_anonymous += 1

    if closed_anonymous != 0:
        closed_media_anonymous_days = round((closed_anonymous_days / closed_anonymous), 2)
    else:
        closed_media_anonymous_days = 0

    if closed_confidential != 0:
        closed_media_confidential_days = round((closed_confidential_days / closed_confidential), 2)
    else:
        closed_media_confidential_days = 0

    #creo il file csv
    log.info("Segnalazioni [nuove] anonime " + str(new_anonymous))
    log.info("Segnalazioni [nuove] confidenziali " + str(new_confidential))
    log.info("Segnalazioni [in lavorazione] anonime " + str(opened_anonymous))
    log.info("Segnalazioni [in lavorazione] confidenziali " + str(opened_confidential))
    log.info("Segnalazioni chiuse anonime " + str(closed_anonymous) + " " + str(closed_media_anonymous_days))
    log.info("Segnalazioni chiuse confidenziali " + str(closed_confidential) + " " + str(closed_media_confidential_days))

    csv_info += "NUOVA;ANONIMA;"+str(new_anonymous)+";\n"
    csv_info += "NUOVA;CONFIDENZIALE;"+str(new_confidential)+";\n"
    csv_info += "IN LAVORAZIONE;ANONIMA;"+str(opened_anonymous)+";\n"
    csv_info += "IN LAVORAZIONE;CONFIDENZIALE;"+str(opened_confidential)+";\n"
    csv_info += "CHIUSA;ANONIMA;"+str(closed_anonymous)+";"+str(closed_media_anonymous_days).replace('.', ',')+";\n"
    csv_info += "CHIUSA;CONFIDENZIALE;"+str(closed_confidential)+";"+str(closed_media_confidential_days).replace('.', ',')+";\n"

    files = []
    files.append({'fo': BytesIO(csv_info.encode()), 'name': 'report_all_'+start_date+'_'+end_date+'.csv'})

    return files


@transact
def perform_deleted_tips_export(session, start_date, end_date):
    """
    Transaction for performing operation on submissions (postpone/delete)

    :param session: An ORM session
    :param tid: A tenant ID
    :param receiver_id: A recipient ID
    :param start_date: The start date for query
    :param end_date: The end date for query
    """

    csv_info = "STATISTICHE RELATIVE ALLE SEGNALAZIONI CANCELLATE;;;;\n"
    csv_info += "DATA INIZIO:;"+start_date+";;;\n"
    csv_info += "DATA FINE:;"+end_date+";;;\n\n"
    csv_info += "STATO SEGNALAZIONE;TIPOLOGIA SEGNALAZIONE;\n"

    start_date_obj = datetime.strptime(start_date, '%d-%m-%Y')
    end_date_obj = datetime.strptime(end_date, '%d-%m-%Y')

    deltips = session.query(models.DeletedTipHistory) \
                   .filter(models.DeletedTipHistory.creation_date >= start_date_obj,
                           models.DeletedTipHistory.creation_date <= end_date_obj)

    deleted_anonymous = 0
    deleted_confidential = 0
    deleted_nc = 0

    for tip in deltips:
        confidential = tip.is_confidential

        if confidential is None:
            deleted_nc += 1
        else:
            if confidential:
                deleted_confidential += 1
            else:
                deleted_anonymous += 1

    #creo il file csv
    #sto dando per scontato che l'unico stato possibile per una segnalazione cancellata sia 'CHIUSA'
    log.info("Segnalazioni [cancellate] anonime " + str(deleted_anonymous))
    log.info("Segnalazioni [cancellate] confidenziali " + str(deleted_confidential))
    csv_info += "CHIUSA;NON CLASSIFICATA;" + str(deleted_nc) + ";\n"
    csv_info += "CHIUSA;ANONIMA;"+str(deleted_anonymous)+";\n"
    csv_info += "CHIUSA;CONFIDENZIALE;"+str(deleted_confidential)+";\n"

    files = []
    files.append({'fo': BytesIO(csv_info.encode()), 'name': 'report_del_'+start_date+'_'+end_date+'.csv'})

    return files


@transact
def get_user_pgp_key(session, tid, user_id):
    user = session.query(models.User).filter(models.User.id == user_id,
                                             models.User.tid == tid).one_or_none()

    if not user:
        raise errors.ResourceNotFound

    return user.pgp_key_public


class MyExportHandler(BaseHandler):
    check_roles = 'receiver'
    handler_exec_time_threshold = 3600

    @inlineCallbacks
    def get(self):
        op = self.request.args.get(b"op")[0]    #operation
        sd = self.request.args.get(b"sd")[0]    #start date
        ed = self.request.args.get(b"ed")[0]    #end date

        pgp_key = yield get_user_pgp_key(self.request.tid, self.session.user_id)

        if op.decode() == 'all':
            filename = "stats_all_tips.zip"
            files = yield prepare_all_tips_export(self.request.tid, self.session.user_id, \
                                                sd.decode(), ed.decode(), self.request.language, self.session.cc)
        elif op.decode() == 'del':
            filename = "stats_all_deleted_tips.zip"
            files = yield perform_deleted_tips_export(sd.decode(), ed.decode())
        else:
            raise errors.ForbiddenOperation

        zipstream = ZipStream(files)

        stf = SecureTemporaryFile(self.state.settings.tmp_path)

        with stf.open('w') as f:
            for x in zipstream:
                f.write(x)
            f.finalize_write()

        with stf.open('r') as f:
            yield self.write_file_as_download(filename, f, pgp_key)
